module.exports = {
  "development": {
    "username": "sql10515964",
    "password": "XWnPwxHgkB",
    "database": "sql10515964",
    "host": "sql10.freemysqlhosting.net",
    "dialect": "mysql",
    "dateStrings": true
  },
  "test": {
    "username": "sql10515964",
    "password": "XWnPwxHgkB",
    "database": "sql10515964",
    "host": "sql10.freemysqlhosting.net",
    "dialect": "mysql",
    "dateStrings": true
  },
  "production": {
    "username": "sql10515964",
    "password": "XWnPwxHgkB",
    "database": "sql10515964",
    "host": "sql10.freemysqlhosting.net",
    "dialect": "mysql",
    "dateStrings": true
  }
}
